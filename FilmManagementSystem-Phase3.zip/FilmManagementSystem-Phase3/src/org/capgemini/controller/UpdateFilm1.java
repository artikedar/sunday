package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.service.FilmServiceImpl;
import com.flp.service.IFilmService;

/**
 * Servlet implementation class UpdateFilm1
 */
public class UpdateFilm1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService=new FilmServiceImpl();
		List<Film> films=new ArrayList<>();
		films=filmService.getAllFilms();
		Actor actor=new Actor();
		Language la=new Language();
	
		
		PrintWriter out=response.getWriter();
		out.println("<html>"
				+ "<head>Delete Films</head>"
				+ "<body>"
				+ "<table border='1'>"
				
				+ "<tr>"
				+ "<th>FilmId</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Original Language</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Rating</th>"
				+ "<th>Special Features</th>"
				+ "<th>Category</th>"
				+ "<th>List of Actors</th>"
				+ "<th>List of Other Languages</th>"
				+ "<th>Delete</th>"
				+ "</tr>");
				
	
				for(Film allFilms:films){
					
					out.println(
							
					"<tr>"
					+"<td name='id' value='"+allFilms.getFilm_ID()+"'>"+allFilms.getFilm_ID()+"</td>"
					+"<td name='filmTilte' value='"+allFilms.getTitle()+"'>"+allFilms.getTitle()+"</td>"
					+"<td name='descrp' value='"+allFilms.getDescription()+"'>"+allFilms.getDescription()+"</td>"
					+"<td name='relDate' value='"+allFilms.getReleaseYear()+"'>"+allFilms.getReleaseYear()+"</td>"
					
					
					+"<td name='orgLang' value='"+allFilms.getOriginalLanguage().getLanguage_Id()+"'>"+(allFilms.getOriginalLanguage()).getName()+"</td>"
					
					
					
					+"<td name='relDur' value='"+allFilms.getRentalDuration()+"'>"+allFilms.getRentalDuration()+"</td>"
					+"<td name='length' value='"+allFilms.getLength()+"'>"+allFilms.getLength()+"</td>"
					+"<td name='cost' value='"+allFilms.getReplacementCost()+"'>"+allFilms.getReplacementCost()+"</td>"
					+"<td name='rating' value='"+allFilms.getRatings()+"'>"+allFilms.getRatings()+"</td>"
					+"<td name='spcfeat' value='"+allFilms.getSpecialFeatures()+"'>"+allFilms.getSpecialFeatures()+"</td>"
					+"<td name='category' value='"+allFilms.getCategory().getCategory_Id()+"'>"+(allFilms.getCategory()).getName()+"</td>");
					
					Set<Actor> act=allFilms.getActors();
					out.println("<td name='actors' value='"+actor.getActor_Id()+"'>");
					for(Actor actors:act){
						String actor2=actors.getFirst_Name()+actors.getLast_Name();
						out.println(actor2); 
					}
					out.println("</td>");
					
					List<Language> langs=allFilms.getLanguages();
					out.println("<td name='otherLang' value='"+la.getLanguage_Id()+"'>");
					for(Language otherLan:langs){
						String lang=otherLan.getName();
						out.println(lang); 
					}
					out.println("</td>");
					
					out.println(
					
					 
						"<td><a href='UpdateFilm2?id="+allFilms.getFilm_ID()+"'>Update</a></td>"
						+ "</tr>");
					//System.out.println(allFilms.getFilm_ID());
				}
				
				out.println(		
				
				"</table>"
				+ "</body>"
				+ "</html>");
		
		
	}

}
