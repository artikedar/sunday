package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.service.ActorServiceImpl;
import com.flp.service.FilmServiceImpl;
import com.flp.service.IFilmService;

/**
 * Servlet implementation class UpdateFilm2
 */
public class UpdateFilm2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int upFilmId=Integer.parseInt(request.getParameter("id"));
		System.out.println("Film ID is:" +upFilmId);
		
		
		
		IFilmService filmService=new FilmServiceImpl();
		List<Category> categories=filmService.getCategories();
		List<Language> lang=filmService.getLanguages();
		
		Actor actor=new Actor();
		ActorServiceImpl actorServiceImpl=new ActorServiceImpl();
		Set<Actor> actors=actorServiceImpl.getActors();
		
		List<Film> films=new ArrayList<>();
	
		Film film=filmService.updateFilm(upFilmId);
		System.out.println("Reached Update Film2 with film:" + film);
		List<Language> lan=film.getLanguages();
		Language orLan=film.getOriginalLanguage();
		Set<Actor> acts=film.getActors();
		
			
		PrintWriter out=response.getWriter();
		out.println("<html>"
				+ "<head>"
				+ "<title>Create Film</title>"
				+ "<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
				+ "<script src='//code.jquery.com/jquery-1.10.2.js'></script>"
				+ "<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>"
				+ "<script type='text/javascript' src='script/validateFilm.js'></script>"
				+ "<link type='text/css' rel='stylesheet' href='css/MyStyle.css'>"
				+ "<script>$(function() {$( '#datepicker' ).datepicker();});</script>"
				+ "<script>$(function() {$( '#datepicker1' ).datepicker();});</script>"
				+ "<script>$(document).ready(function() {$('#start_datepicker')datepicker();$('#end_datepicker').datepicker();});</script>"
				+ "</head>"
				
				
				                           
				+ "<body>"
				+ "<form action='UpdateFilm3' method='post' name='updateFilm'>"
				+ "<table>"
				+ "<h3>Update Film</h3> "
				
				
				//film title
				+ "<tr>"
				+ "<td>Title</td>"
				+ "<td><input type='text' name='filmTilte' value='"+film.getTitle()+"' onmouseout='return titleValidation();'>"
				+ "<div id='titleErr' class='errMsg'></div></td>"
				+ "</tr>"
				
				
				//description
				+ "<tr>"
				+ "<td>Description</td>"
				+ "<td><input type='text' name='descrp'value='"+film.getDescription()+"'></td>"
				+ "</tr>"
				
				
				//release Year
				+ "<tr>"
				+ "<td>Release Year</td>"
				+ "<td><input type='text' name='relDate' id='datepicker1' value='"+film.getReleaseYear()+"' onmouseout='return releaseYearValidation();'>"
				+ "<div id='relYearErr' class='errMsg'></div></td>"
				+ "</tr>"
				
				
				//original language
				+ "<tr>"
				+ "<td>Select Original Language</td>"
				+ "<td><select name='orgLang' value='"+film.getOriginalLanguage()+"'>");
				//System.out.println(upFilmId);
				for(Language language:lang){
						//System.out.println(language);
						//System.out.println(film.getOriginalLanguage().getName());
						if(language.getName().equals(film.getOriginalLanguage().getName())){
						out.println("<option value='"+language.getLanguage_Id()+"'selected>"+language.getLanguage_Id()+" "+language.getName()+"</option>");
						}
				}
				
				out.println(
				"</td></select>"
						
				
				
				//other languages
				+ "<tr>"
				+ "<td>Select Other Language</td>"
				+ "<td><select name='otherLang' value='' multiple>");
				boolean flag1=false;
				int id2=0;
				
				for(Language language:lang){
					
					for(Language lans:lan){
						
						if(language.getName().equals(lans.getName())){
							flag1=true;
							id2=language.getLanguage_Id();
						}
					
					}
					if(flag1==true&&id2==language.getLanguage_Id()){
						out.println("<option value='"+language.getLanguage_Id()+"'selected>"+language.getLanguage_Id()+" "+language.getName()+"</option>");
					}
					else
						out.println("<option value='"+language.getLanguage_Id()+"'>"+language.getLanguage_Id()+" "+language.getName()+"</option>");
				}
				
				
				out.println(
				"</td></select>");
				
				//actors
				out.println("<tr>"
						+ "<td>Select Actors</td>"
						+ "<td><select name='actors' multiple>");
				boolean flag=false;
				int id1=0;
				
				for(Actor act:actors){
					for(Actor act1:acts){
						if(act.getFirst_Name().equals(act1.getFirst_Name()) && act.getLast_Name().equals(act1.getLast_Name())){
							flag=true;
							id1=act.getActor_Id();
							//out.println("<option value=" +act.getActor_Id()+ ">"+act.getFirst_Name()+act.getLast_Name()+"</option>");
						}
					}
					if(flag==true && id1==act.getActor_Id())
						out.println("<option value='"+act.getActor_Id()+"'selected>"+act.getActor_Id()+" "+act.getFirst_Name()+act.getLast_Name()+"</option>");
					else
						out.println("<option value='"+act.getActor_Id()+"'>"+act.getActor_Id()+" "+act.getFirst_Name()+act.getLast_Name()+"</option>");
				}
				out.println(
						"</td></select>");
					
				
				//rental duration								
				out.println("<tr>"
				+ "<td>Rental Duration</td>"
				+ "<td><input type='text' name='relDur' id='datepicker' value='"+film.getRentalDuration()+"' onmouseout='return rentalDurationValidation();'>"
				+ "<div id='renDurErr' class='errMsg'></div></td>"
				+ "</tr>"
				
				
				//rating
				+ "<tr>"
				+ "<td>Rating</td>"
				+ "<td><select name='rating'>");
				
				for(int i=0;i<=5;i++){
					if(i==film.getRatings()){
						out.print("<option value='"+i+"' selected>"+i+"</option>");
						}
					else
						out.print("<option value='"+i+"' >"+i+"</option>");
				}
				
				out.println("<option value='1'>1</option>"
				+ "<option value='2'>2</option>"
				+ "<option value='3'>3</option>"
				+ "<option value='4'>4</option>"
				+ "<option value='5'>5</option>"
				+ "</select></td>"
				+ "</tr>"
				
				
				//special features
				+ "<tr>"
				+ "<td>Special Features</td>"
				+ "<td><input type='text' name='spcfeat' value='"+film.getSpecialFeatures()+"' onmouseout='return specialFeaturesValidation();'>"
				+ "<div id='specialFeaturesErr' class='errMsg'></div></td>"
				+ "</tr>"
				
				
				//length
				+ "<tr>"
				+ "<td>Length</td>"
				+ "<td><input type='text' name='length' value='"+film.getLength()+"' onmouseout='return lengthValidation();'>"
				+ "<div id='lengthErr' class='errMsg'></div></td>"
				+ "</tr>"
				
				
				//replacement cost
				+ "<tr>"
				+ "<td>Replacement Cost:</td>"
				+ "<td> <input type='text' name='cost' value='"+film.getReplacementCost()+"' onmouseout='return replacementCostValidation();'>"
				+ "<div id='repCostErr' class='errMsg'></div></td>"
				+ "</tr>"
				
				+ "<tr>"
				+ "<td>Select Category</td>"
				+ "<td><select name='category'>");
				
				for(Category category:categories){
					if(category.getName().equals(film.getCategory().getName())){
						out.println("<option value='"+category.getCategory_Id()+"'selected>"+category.getCategory_Id()+" "+category.getName()+"</option>");
					}
					else
						out.println("<option value='"+category.getCategory_Id()+"'>"+category.getCategory_Id()+" "+category.getName()+"</option>");
				}

		
				out.println("</td></select>"
				
				+ "<tr>"
				+ "<td></td>"
				+ "<td>"
				+ "<tr>"
				+ "<input type='hidden' name='filmId' value='"+upFilmId+"'>"
				+ "<input type='submit' value='Save'>"
				+ "<input type='reset' value='Clear'>"
				+ "</td>"
				+ "</tr>"							
				+ "</table>"
				+ "</body>"
				+ "</html>");
		
		
		

	}

}
